# CleanSalone SL - Algorithm and Testing Notes

## Step-by-Step Algorithm
1. Capture area, ward, location, category, volume and risk indicators.
2. Validate all mandatory fields; ask for correction or allow cancellation if invalid.
3. Look for an unresolved report with matching location and category in the previous 72 hours.
4. If a duplicate exists, merge the new information, reassess priority, preserve the case ID and refresh the route/status when needed.
5. Otherwise generate a new case ID.
6. Route medical/hazardous waste to specialist review; do not send it to ordinary collection.
7. For other categories, calculate the risk score and classify priority.
8. Look up the approved route by area/ward; if missing, request manual routing.
9. Save the case/status and display the reference and next steps.
10. During queue review, refresh age-related priority and flag cases without an update for three days or more.

## Risk Score
- Affects or blocks drain/waterway: +3
- Overflow obstructs road/public area: +2
- Large volume: +2
- Near school/clinic/market/designated sensitive site: +2
- Illegal dumping or open burning: +2
- Open report waiting 3 days or more: +1

Thresholds: score >= 6 = HIGH; 3-5 = MEDIUM; 0-2 = ROUTINE. Medical or hazardous waste receives SPECIALIST ESCALATION independently of score. All values are illustrative pilot parameters, not official national standards.

## Expected Test Cases
| ID | Case | Expected result |
|---|---|---|
| T1 | Valid ordinary report with score 0 | New ID, ROUTINE |
| T2 | Total score exactly 3 | MEDIUM |
| T3 | Total score exactly 6 | HIGH |
| T4 | Same unresolved location/category inside 72 hours | Existing ID reused |
| T5 | Medical/hazardous waste | Specialist escalation |
| T6 | Missing location | Validation error, no case created |
| T7 | Ward has no route record | Needs manual routing |
| T8 | Open case reaches 3 days | Add age point and follow-up flag |
| T9 | Unauthorised status update | Deny update |
| T10 | Aggregate export | CSV with approved fields only |

## Safety and Operational Notes
- The tool does not make a scientific assessment of hazardous waste.
- A score is a triage aid, not a determination of legal responsibility.
- Service directory, categories and thresholds must be approved and maintained by the participating local council.
- Do not promise a collection date until the responsible provider confirms it.
