# Evidence to Add Before Submission

This folder is reserved for genuine screenshots captured from the student's own GitHub account. Add:

- `repository-screenshot.png` — repository page showing the correct repository name and files.
- `commit-history-screenshot.png` — actual commit history with meaningful commits.

Do not fabricate or edit evidence to imply activity that did not occur. Replace placeholders in the report and add the actual repository URL before submitting.
